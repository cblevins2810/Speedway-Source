update pos_button_template 
set pos_file_id = 136
where pos_file_id = 208
and pos_frame_template_id = 1000103