DROP INDEX [XAKdiscount_XREF_name] ON [dbo].[Discount]
GO
