/****** Object:  Table [dbo].[bc_extract_bu_price_change_item]    Script Date: 08/30/2018 22:06:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[bc_extract_bu_price_change_item](
	[item_id] [int] NOT NULL,
	[name] [nvarchar](50) NOT NULL
) ON [PRIMARY]

GO

